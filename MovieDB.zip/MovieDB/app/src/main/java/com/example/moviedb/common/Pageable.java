package com.example.moviedb.common;


public interface Pageable {
}
