package com.example.moviedb.delegate;

public interface MovieDelegate {
    void onGiveRemark(int movieId);
}
