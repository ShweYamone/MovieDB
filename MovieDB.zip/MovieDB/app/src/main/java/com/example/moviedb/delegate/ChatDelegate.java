package com.example.moviedb.delegate;

public interface ChatDelegate {
    void deleteChatMessage(String messageId,int position);
}
