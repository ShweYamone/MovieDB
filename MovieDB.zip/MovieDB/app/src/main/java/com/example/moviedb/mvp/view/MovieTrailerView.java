package com.example.moviedb.mvp.view;

import com.example.moviedb.model.GetVideoResultModel;

public interface MovieTrailerView extends BaseView {
    void showVideo(GetVideoResultModel getVideoResultModel);

}
