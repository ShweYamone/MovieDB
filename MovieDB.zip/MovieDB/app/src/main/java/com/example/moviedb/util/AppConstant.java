package com.example.moviedb.util;

/**
 * Created by kaungkhantsoe on 2019-10-19.
 **/
public class AppConstant {

    public static final String BASE_URL = "https://api.themoviedb.org/3/";
    public static final String BASE_IMG_URL = "https://image.tmdb.org/t/p/w500";
    public static final String DEVELOPER_KEY = "4d3dff8812b4d88b8f7ec0e4d5ce7a68";

    public static final String ZG_FONT = "zg";
    public static final String MM3_FONT = "mm3";
}
