package com.example.moviedb.mvp.view;

public interface MainView extends BaseView {

}
