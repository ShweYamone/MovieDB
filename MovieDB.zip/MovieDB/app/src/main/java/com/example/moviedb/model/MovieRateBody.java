package com.example.moviedb.model;

public class MovieRateBody {
    float value;

    public MovieRateBody(float value) {
        this.value = value;
    }
}
